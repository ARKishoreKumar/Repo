package em.dataguard.S3;


import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import em.dataguard.payload.EmDgS3DetailsDTO;
import org.apache.commons.io.FileUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;


@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/s3")
public class S3Controller {

    @PostMapping("/backup")
    public void backupS3(@RequestBody EmDgS3DetailsDTO emDgS3DetailsDTO) {

        String  bucketName = emDgS3DetailsDTO.getBucketName();
        String key = emDgS3DetailsDTO.getKey();
        AWSCredentials credentials = new BasicAWSCredentials (
                "AKIAZIS5AS6ZPPLRI3FA",
                "z22E2PvyoQiUXdTzRPpilaZNjmZb+aS4qBhkJ1O1"
        );
        //set-up the client
        AmazonS3 s3client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(Regions.AP_SOUTH_1)
                .build();

        AWSS3Service awsService = new AWSS3Service(s3client);

        //bucketName = "eminds-bucket-abc-test";

        awsService.createBucket(bucketName);

      /*  //list all the buckets
        for(Bucket s : awsService.listBuckets() ) {
            System.out.println(s.getName());
        }*/

        //deleting bucket
         // awsService.deleteBucket(bucketName);

        //uploading object
        awsService.putObject(
                bucketName,
                key+".sql",
                new File("external\\sql\\"+key+".sql")
        );
    }

    @PostMapping("/restore")
    public void restoreS3(@RequestBody EmDgS3DetailsDTO emDgS3DetailsDTO)  throws IOException
    {
        String  bucketName = emDgS3DetailsDTO.getBucketName();
        String key = emDgS3DetailsDTO.getKey();

        AWSCredentials credentials = new BasicAWSCredentials (
                "AKIAZIS5AS6ZPPLRI3FA",
                "z22E2PvyoQiUXdTzRPpilaZNjmZb+aS4qBhkJ1O1"
        );

        AmazonS3 s3client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(Regions.AP_SOUTH_1)
                .build();

        AWSS3Service awsService = new AWSS3Service(s3client);

/*        //listing objects
        ObjectListing objectListing = awsService.listObjects(bucketName);
        for(S3ObjectSummary os : objectListing.getObjectSummaries()) {
            System.out.println(os.getKey());
        } */

        //downloading an object
        S3Object s3object = awsService.getObject(bucketName, key+".sql");
        S3ObjectInputStream inputStream = s3object.getObjectContent();
        FileUtils.copyInputStreamToFile(inputStream, new File("external\\s3\\"+key+".sql"));

    }
}
