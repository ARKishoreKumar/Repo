package em.dataguard.buslogic.data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

@Repository
public class MySQLBackupRestoreTestService {

	private Logger logger = LoggerFactory.getLogger(getClass());
	private static final String TEST_DB = "ems";
	private static final String RESTORED_DB = "ems";
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "root";
	private static final String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";

	void givenDBCredentials_whenExportDatabaseAndImportDatabase_thenBackUpAndRestoreTestDbSuccessfully()
			throws Exception {

		System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "debug");

		Properties properties = new Properties();
		properties.setProperty(MysqlExportService.DB_NAME, TEST_DB);
		properties.setProperty(MysqlExportService.DB_USERNAME, DB_USERNAME);
		properties.setProperty(MysqlExportService.DB_PASSWORD, DB_PASSWORD);

		properties.setProperty(MysqlExportService.PRESERVE_GENERATED_ZIP, "true");
		properties.setProperty(MysqlExportService.PRESERVE_GENERATED_SQL_FILE, "true");

		properties.setProperty(MysqlExportService.JDBC_DRIVER_NAME, DRIVER_CLASS_NAME);
		properties.setProperty(MysqlExportService.ADD_IF_NOT_EXISTS, "true");

		properties.setProperty(MysqlExportService.TEMP_DIR, new File("external").getPath());
		properties.setProperty(MysqlExportService.SQL_FILE_NAME, "test_output_file_name");

		MysqlExportService mysqlExportService = new MysqlExportService(properties);
		mysqlExportService.export();

		String generatedSql = mysqlExportService.getGeneratedSql();
//        logger.info("generated SQL: \n" + generatedSql);

		File file = mysqlExportService.getGeneratedZipFile();

		System.out.println("Generated Filename: " + file.getAbsolutePath());

		File sqlFile = new File("external/sql/test_output_file_name.sql");
		System.out.println("SQL File name: " + sqlFile.getAbsolutePath());

		String sql = new String(Files.readAllBytes(sqlFile.toPath()));
		MysqlImportService res = MysqlImportService.builder().setJdbcDriver("com.mysql.cj.jdbc.Driver")
				.setDatabase(RESTORED_DB).setSqlString(sql).setUsername(DB_USERNAME).setPassword(DB_PASSWORD)
				.setDeleteExisting(true).setDropExisting(true);

		assertDatabaseBackedUp();
	}

	void skpDatabaseExport(String DB_USERNAME, String DB_PASSWORD, String TEST_DB, String filename ) throws Exception {

		System.out.println("Ready to Take Backup!");
		Properties properties = new Properties();
		properties.setProperty(MysqlExportService.DB_USERNAME, DB_USERNAME);
		properties.setProperty(MysqlExportService.DB_PASSWORD, DB_PASSWORD);
		properties.setProperty(MysqlExportService.DB_NAME, TEST_DB);
		properties.setProperty(MysqlExportService.JDBC_CONNECTION_STRING, "jdbc:mysql://localhost:3306/" + TEST_DB
				+ "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true");

		properties.setProperty(MysqlExportService.PRESERVE_GENERATED_ZIP, "true");
		properties.setProperty(MysqlExportService.PRESERVE_GENERATED_SQL_FILE, "true");
		properties.setProperty(MysqlExportService.SQL_FILE_NAME, filename);
		properties.setProperty(MysqlExportService.ADD_IF_NOT_EXISTS, "true");

		properties.setProperty(MysqlExportService.TEMP_DIR, new File("external").getPath());

		MysqlExportService mysqlExportService = new MysqlExportService(properties);
		mysqlExportService.export();

		String generatedSql = mysqlExportService.getGeneratedSql();

		logger.debug("Final Output:\n {}", generatedSql);

		File file = mysqlExportService.getGeneratedZipFile();

		logger.debug("generated file name: " + file.getAbsolutePath());

	}

	void skpDatabaseImport(String DB_USERNAME, String DB_PASSWORD, String RESTORED_DB, String filename) throws Exception {

		File sqlFile = new File(filename);
		logger.info("SQL File name: " + sqlFile.getAbsolutePath());

		String sql = new String(Files.readAllBytes(sqlFile.toPath()));
		boolean res = MysqlImportService.builder().setSqlString(sql).setJdbcConnString("jdbc:mysql://localhost:3306/"
						+ RESTORED_DB
						+ "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false")
				.setUsername(DB_USERNAME).setPassword(DB_PASSWORD).setDatabase(RESTORED_DB).setDeleteExisting(true)
				.setDropExisting(true).importDatabase();

	}

	private void assertDatabaseBackedUp() throws Exception {
		Connection connection = MysqlBaseService.connect(DB_USERNAME, DB_PASSWORD, RESTORED_DB, DRIVER_CLASS_NAME);
		Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
		statement.execute("SELECT COUNT(1) as total FROM users");
		ResultSet resultSet = statement.getResultSet();
		resultSet.first();
		if (resultSet.getLong("total") > 0) {

			System.out.println("Database Backed Up!");
		}
	}

	

	/*public static void main(String[] args) {

		try {
			new MySQLBackupRestoreTestService().skpDatabaseExport();

			//new MySQLBackupRestoreTestService().skpDatabaseImport();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
*/
}