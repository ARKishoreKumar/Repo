package em.dataguard.buslogic.data;

import em.dataguard.payload.EmDgDatabaseDetailsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/dataguard")
public class controller {

    @Autowired
    MySQLBackupRestoreTestService mySQLBackupRestoreTestService;

    @PostMapping("/backup")
    public void backupDatabase(@RequestBody EmDgDatabaseDetailsDTO emDgDatabaseDetailsDTO)
    {
        try {
            new MySQLBackupRestoreTestService().skpDatabaseExport(
                    emDgDatabaseDetailsDTO.getDbUserName(), emDgDatabaseDetailsDTO.getDbPassword(),
                    emDgDatabaseDetailsDTO.getTestDb(), emDgDatabaseDetailsDTO.getFileName());

            //new MySQLBackupRestoreTestService().skpDatabaseImport();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @PostMapping("/restore")
    public void restoreDatabase(@RequestBody EmDgDatabaseDetailsDTO emDgDatabaseDetailsDTO)
    {
        try {
            // new MySQLBackupRestoreTestService().skpDatabaseExport();

            new MySQLBackupRestoreTestService().skpDatabaseImport(emDgDatabaseDetailsDTO.getDbUserName(), emDgDatabaseDetailsDTO.getDbPassword(),
                    emDgDatabaseDetailsDTO.getTestDb(), "external//sql//" + emDgDatabaseDetailsDTO.getFileName() +".sql");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
