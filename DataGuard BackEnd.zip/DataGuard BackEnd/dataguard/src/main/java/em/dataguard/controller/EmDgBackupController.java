package em.dataguard.controller;

import em.dataguard.model.EmDgBackup;
import em.dataguard.model.EmDgDatabase;
import em.dataguard.payload.EmDgBackupDTO;
import em.dataguard.payload.EmDgBackupDTO1;
import em.dataguard.service.EmDgBackupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.text.*;


@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/backup")
@RestController
public class EmDgBackupController {

    @Autowired
    EmDgBackupService emDgBackupService;

    @PostMapping("/save/{emDgDatabaseId}")
    public ResponseEntity<?> saveBackup(
            @PathVariable(name= "emDgDatabaseId") Long emDgDatabaseId,
            @RequestBody EmDgBackupDTO emDgBackupDTO)
    {
        return emDgBackupService.saveBackup(emDgDatabaseId,emDgBackupDTO);
    }

    @GetMapping("/get")
    public List<EmDgBackup> getAllDatabaseBackup() {
        return emDgBackupService.getAllBackups();
    }

    @GetMapping("/get/{emDgBackupId}")
    public EmDgBackup getDatabaseBackupDetailsByID(@PathVariable("emDgBackupId") long emDgBackupId)
    {
        return emDgBackupService.getBackupById(emDgBackupId);
    }

    @GetMapping("/datavalues")
    public EmDgBackupDTO1 listDataValues( )
    {
        EmDgBackupDTO1 ob = new EmDgBackupDTO1();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dataguard","root","root");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select em_dg_backup_time_stamp, em_dg_backup_name, em_dg_backup_description from em_dg_backup order by em_dg_backup_time_stamp desc");
            DateFormat fmt = DateFormat.getDateTimeInstance (DateFormat.MEDIUM,
                    DateFormat.MEDIUM, Locale.UK);
            if(rs.next()) {
                ob.setEmDgBackupTimeStamp(fmt.format(rs.getTimestamp(1)));
                ob.setEmDgBackupName(rs.getString(2));
                ob.setEmDgBackupDescription(rs.getString(3));
            }
        }
        catch(Exception e)
        {

        }
        return ob;
    }
}
