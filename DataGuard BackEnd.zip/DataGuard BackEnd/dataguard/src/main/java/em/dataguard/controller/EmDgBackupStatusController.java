package em.dataguard.controller;

import em.dataguard.model.EmDgBackupStatus;
import em.dataguard.service.EmDgBackupService;
import em.dataguard.service.EmDgBackupStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/backupstatus")
@RestController

public class EmDgBackupStatusController {

    @Autowired
    EmDgBackupStatusService emDgBackupStatusService;

    @PostMapping("/save")
    public ResponseEntity<?> saveBackupStatus(@RequestBody EmDgBackupStatus emDgBackupStatus)
    {
        return emDgBackupStatusService.saveStatus(emDgBackupStatus);
    }
@GetMapping("/get")
    public List<EmDgBackupStatus> listAllBackupStatus()
    {
        return emDgBackupStatusService.listAllStatus();
    }
@GetMapping("/get/{emDgBackupStatusId}")
    public EmDgBackupStatus listById(@PathVariable Long emDgBackupStatusId)
    {
        return emDgBackupStatusService.getById(emDgBackupStatusId);
    }
}
