package em.dataguard.controller;


import em.dataguard.model.EmDgDatabase;
import em.dataguard.payload.EmDgDatabaseDTO;
import em.dataguard.service.EmDgDatabaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/database")
@RestController
public class EmDgDatabaseController {



    @Autowired
    EmDgDatabaseService emDgDatabaseService;

    @PostMapping("/save")
    public ResponseEntity<?> createDbDetails(@RequestBody EmDgDatabaseDTO emDgDatabaseDTO) {
        return  emDgDatabaseService.saveDatabase(emDgDatabaseDTO);
    }

    @GetMapping("/get")
    public List<EmDgDatabase> getAllDatabaseDetails() {
        return emDgDatabaseService.findAllDatabases();
    }

    @GetMapping("/get/{emDgDatabaseId}")
    public EmDgDatabase getDatabaseDetailsByID(@PathVariable("emDgDatabaseId") long emDgDatabaseId)
    {
        return emDgDatabaseService.findDatabaseById(emDgDatabaseId);
    }


    @GetMapping("/get/db/{emDgDatabaseDbType}/{emDgDatabaseServerName}/{emDgDatabasePortNumber}/{emDgDatabaseUserName}/{emDgDatabasePassword}")
    public Set<String> listDB(@PathVariable String emDgDatabaseDbType, @PathVariable String emDgDatabaseServerName,
                              @PathVariable String emDgDatabasePortNumber, @PathVariable String emDgDatabaseUserName,
                              @PathVariable String emDgDatabasePassword )
    {
        Set<String> hs = new HashSet<String>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:" + emDgDatabaseDbType +"://" + emDgDatabaseServerName +":" + emDgDatabasePortNumber + "/" ,emDgDatabaseUserName,emDgDatabasePassword  );
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("Show databases");

            while(rs.next()) {
                hs.add(rs.getString(1));
            }
        }
        catch(Exception e)
        {

        }
        return hs;
    }






}
