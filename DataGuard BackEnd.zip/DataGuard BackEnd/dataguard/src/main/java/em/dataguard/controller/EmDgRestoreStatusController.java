package em.dataguard.controller;



import em.dataguard.model.EmDgRestoreStatus;
import em.dataguard.service.EmDgRestoreStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/restorestatus")
@RestController
public class EmDgRestoreStatusController {

    @Autowired
    EmDgRestoreStatusService emDgRestoreStatusService;

    @PostMapping("/save")
    public ResponseEntity<?> saveBackupStatus(@RequestBody EmDgRestoreStatus emDgRestoreStatus)
    {
        return emDgRestoreStatusService.saveStatus(emDgRestoreStatus);
    }
@GetMapping("/get")
    public List<EmDgRestoreStatus> listAllBackupStatus()
    {
        return emDgRestoreStatusService.listAllStatus();
    }

    @GetMapping("/get/{emDgRestoreStatusId}")
    public EmDgRestoreStatus listById(@PathVariable Long emDgRestoreStatusId)
    {
        return emDgRestoreStatusService.getById(emDgRestoreStatusId);
    }
}
