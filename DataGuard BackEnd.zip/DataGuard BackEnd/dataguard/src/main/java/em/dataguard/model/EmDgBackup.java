package em.dataguard.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="EM_DG_BACKUP")
public class EmDgBackup {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "backup_generator")
    @SequenceGenerator(name="backup_generator", sequenceName = "backup_seq", initialValue = 101, allocationSize = 1)

    private long emDgBackupId;
    private String emDgBackupName;
    private String emDgBackupDescription;

    private Date emDgBackupTimeStamp;
    private long emDgBackupSize;
    private long emDgBackupS3Id;
    private String emDgBackupS3Path;
    private String emDgBackupType;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name="emDgDatabase_Id", nullable = false)
    private EmDgDatabase emDatabase;

    @OneToMany(mappedBy = "emBackup")
    @JsonIgnore
    private Set<EmDgRestore> emDgRestore;
}
