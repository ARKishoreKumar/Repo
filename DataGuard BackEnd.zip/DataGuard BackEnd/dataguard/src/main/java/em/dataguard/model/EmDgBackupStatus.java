package em.dataguard.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="EM_DG_BACKUP_STATUS")
public class EmDgBackupStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "backup_status_generator")
    @SequenceGenerator(name="backup_status_generator", sequenceName = "backup_status_seq", initialValue = 1, allocationSize = 1)

    private long emDgBackupStatusId;

    private long emDgBackupId;

    private String emDgBackupStatus;
}
