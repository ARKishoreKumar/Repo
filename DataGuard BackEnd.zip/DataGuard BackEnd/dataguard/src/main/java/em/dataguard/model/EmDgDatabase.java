package em.dataguard.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="EM_DG_DATABASE")
public class EmDgDatabase {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "db_generator")
    @SequenceGenerator(name="db_generator", sequenceName = "db_seq", initialValue = 10001, allocationSize = 1)

    private long emDgDatabaseId;
    private String emDgDatabaseDbType;
    private String emDgDatabaseServerName;
    private long emDgDatabasePortNumber;
    private String emDgDatabaseUserName;
    private String emDgDatabasePassword;
    private String emDgDatabaseSchemas;
    private String emDgDatabaseName;
    private String emDgFriendlyDatabaseName;
    private String emDgFriendlyDatabaseDescription;
    private String emDgDatabaseDiskPath;

    @OneToMany(mappedBy = "emDatabase")
    @JsonIgnore
    private Set<EmDgBackup> emDgBackup;


}
