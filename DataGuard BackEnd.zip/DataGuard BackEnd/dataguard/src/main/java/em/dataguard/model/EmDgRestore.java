package em.dataguard.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="EM_DG_RESTORE")
public class EmDgRestore {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "restore_generator")
    @SequenceGenerator(name="restore_generator", sequenceName = "restore_seq", initialValue = 201, allocationSize = 1)
    private long emDgRestoreId;
    private String emDgRestoreName;
    private String emDgRestoreDescription;
    private Date emDgRestoreTimeStamp;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name="emDgBackup_Id", nullable = false)
    private EmDgBackup emBackup;
}
