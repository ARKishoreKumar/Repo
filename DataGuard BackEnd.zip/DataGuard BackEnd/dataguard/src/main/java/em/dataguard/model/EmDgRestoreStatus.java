package em.dataguard.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="EM_DG_Restore_STATUS")
public class EmDgRestoreStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "restore_status_seq")
    @SequenceGenerator(name="backup_status_seq", sequenceName = "restore_status_seq", initialValue = 1, allocationSize = 1)

    private long emDgRestoreStatusId;
    private String emDgRestoreStatus;
    private long emDgRestoreId;
}
