package em.dataguard.payload;

import lombok.Data;

import java.util.Date;

@Data

public class EmDgBackupDTO {
    private long emDgBackupId;
    private String emDgBackupName;
    private String emDgBackupDescription;
    private Date emDgBackupTimeStamp;
    private long emDgBackupSize;
    private long emDgBackupS3Id;
    private String emDgBackupS3Path;
    private String emDgBackupType;
}
