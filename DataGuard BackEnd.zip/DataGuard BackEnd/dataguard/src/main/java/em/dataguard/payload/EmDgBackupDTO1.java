package em.dataguard.payload;

import lombok.Data;

import java.util.Date;


@Data
public class EmDgBackupDTO1 {

    private String emDgBackupTimeStamp;
    private String emDgBackupName;
    private String emDgBackupDescription;


}
