package em.dataguard.payload;

import lombok.Data;

@Data
public class EmDgDatabaseDTO {
    private long emDgDatabaseId;
    private String emDgDatabaseDbType;
    private String emDgDatabaseServerName;
    private long emDgDatabasePortNumber;
    private String emDgDatabaseUserName;
    private String emDgDatabasePassword;
    private String emDgDatabaseSchemas;
    private String emDgDatabaseName;
    private String emDgFriendlyDatabaseName;
    private String emDgFriendlyDatabaseDescription;
    private String emDgDatabaseDiskPath;
}
