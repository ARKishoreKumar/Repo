package em.dataguard.payload;

import lombok.Data;

@Data

public class EmDgDatabaseDetailsDTO {
    String dbUserName;
    String dbPassword;
    String testDb;
    String fileName;
}
