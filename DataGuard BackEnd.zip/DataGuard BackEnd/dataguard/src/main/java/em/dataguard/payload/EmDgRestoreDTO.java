package em.dataguard.payload;

import lombok.Data;

import java.util.Date;
@Data
public class EmDgRestoreDTO {
    private long emDgRestoreId;
    private String emDgRestoreName;
    private String emDgRestoreDescription;
    private Date emDgRestoreTimeStamp;
}
