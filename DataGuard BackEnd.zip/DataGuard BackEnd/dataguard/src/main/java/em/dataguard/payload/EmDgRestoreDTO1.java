package em.dataguard.payload;

import lombok.Data;

import java.util.Date;

@Data
public class EmDgRestoreDTO1 {

    private String emDgRestoreName;
    private String emDgRestoreDescription;
    private String emDgRestoreTimeStamp;
}
