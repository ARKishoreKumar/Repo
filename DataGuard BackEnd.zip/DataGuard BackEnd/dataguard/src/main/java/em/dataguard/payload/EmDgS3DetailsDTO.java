package em.dataguard.payload;

import lombok.Data;

@Data
public class EmDgS3DetailsDTO {
    String bucketName;
    String key;
}
