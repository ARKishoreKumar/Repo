package em.dataguard.repository;

import em.dataguard.model.EmDgBackup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmDgBackupRepository extends JpaRepository<EmDgBackup, Long> {
}
