package em.dataguard.repository;

import em.dataguard.model.EmDgRestore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmDgRestoreRepository extends JpaRepository<EmDgRestore, Long> {
}
