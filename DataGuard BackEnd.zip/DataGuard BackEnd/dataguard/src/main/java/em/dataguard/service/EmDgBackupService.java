package em.dataguard.service;

import em.dataguard.model.EmDgBackup;
import em.dataguard.payload.EmDgBackupDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface EmDgBackupService {
    public ResponseEntity<?> saveBackup(Long emDgDatabaseId, EmDgBackupDTO emDgBackupDTO);
    public List<EmDgBackup> getAllBackups();

    public EmDgBackup getBackupById(Long emDgBackupId);
}
