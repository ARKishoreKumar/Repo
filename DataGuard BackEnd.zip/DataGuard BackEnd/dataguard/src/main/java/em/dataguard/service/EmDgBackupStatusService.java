package em.dataguard.service;

import em.dataguard.model.EmDgBackupStatus;
import em.dataguard.repository.EmDgBackupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface EmDgBackupStatusService {

    public ResponseEntity<?> saveStatus(EmDgBackupStatus emDgBackupStatus);

    public List<EmDgBackupStatus> listAllStatus();

    public EmDgBackupStatus getById(Long emDgBackupStatusId);
}
