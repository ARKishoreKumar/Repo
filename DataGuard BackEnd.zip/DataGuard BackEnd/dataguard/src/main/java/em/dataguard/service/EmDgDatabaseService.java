package em.dataguard.service;

import em.dataguard.model.EmDgDatabase;
import em.dataguard.payload.EmDgDatabaseDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface EmDgDatabaseService {
    public ResponseEntity<?> saveDatabase(EmDgDatabaseDTO emDgDatabase);
    public List<EmDgDatabase> findAllDatabases();
    public EmDgDatabase findDatabaseById(Long emDgDatabaseId);
}
