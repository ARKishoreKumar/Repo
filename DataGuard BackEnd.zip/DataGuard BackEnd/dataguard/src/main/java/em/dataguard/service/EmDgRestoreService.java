package em.dataguard.service;

import em.dataguard.model.EmDgRestore;
import em.dataguard.payload.EmDgRestoreDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface EmDgRestoreService {
    public ResponseEntity<?> saveRestore(Long emDgBackupId, EmDgRestoreDTO emDgRestoreDTO);
    public List<EmDgRestore> getAllRestores();
    public EmDgRestore getRestoreById(Long emDgRestoreId);
}
