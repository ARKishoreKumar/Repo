package em.dataguard.service;

import em.dataguard.model.EmDgRestoreStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface EmDgRestoreStatusService {

    public ResponseEntity<?> saveStatus(EmDgRestoreStatus emDgRestoreStatus);
    public List<EmDgRestoreStatus> listAllStatus();

    public EmDgRestoreStatus getById(Long emDgRestoreStatusId);

}
