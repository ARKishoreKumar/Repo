package em.dataguard.serviceimpl;

import em.dataguard.model.EmDgBackup;
import em.dataguard.model.EmDgBackupStatus;
import em.dataguard.model.EmDgDatabase;
import em.dataguard.payload.EmDgBackupDTO;
import em.dataguard.repository.EmDgBackupRepository;
import em.dataguard.repository.EmDgBackupStatusRepository;
import em.dataguard.repository.EmDgDatabaseRepository;
import em.dataguard.service.EmDgBackupService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmDgBackupServiceImpl implements EmDgBackupService {
    @Autowired
    EmDgBackupRepository emDgBackupRepository;

    @Autowired
    EmDgBackupStatusRepository emDgBackupStatusRepository;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    EmDgDatabaseRepository emDgDatabaseRepository;

    @Override
    public ResponseEntity<?> saveBackup(Long emDgDatabaseId,EmDgBackupDTO emDgBackupDTO) {

            EmDgDatabase emDgDatabase = emDgDatabaseRepository.findById(emDgDatabaseId).get();

            EmDgBackup emDgBackup = modelMapper.map(emDgBackupDTO, EmDgBackup.class);
            emDgBackup.setEmDatabase(emDgDatabase);
            EmDgBackup savedEmDgBackup = emDgBackupRepository.save(emDgBackup);
            modelMapper.map(savedEmDgBackup, EmDgBackupDTO.class);

            EmDgBackupStatus ob = new EmDgBackupStatus();
            ob.setEmDgBackupId(savedEmDgBackup.getEmDgBackupId());
            ob.setEmDgBackupStatus("Success");
            emDgBackupStatusRepository.save(ob);

            return new ResponseEntity<>("Database Backed Up and details saved Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDgBackup> getAllBackups() {
        return emDgBackupRepository.findAll();
    }

    @Override
    public EmDgBackup getBackupById(Long emDgBackupId) {
        return emDgBackupRepository.findById(emDgBackupId).get();
    }
}
