package em.dataguard.serviceimpl;

import em.dataguard.model.EmDgBackupStatus;
import em.dataguard.repository.EmDgBackupStatusRepository;
import em.dataguard.service.EmDgBackupService;
import em.dataguard.service.EmDgBackupStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmDgBackupStatusServiceImpl implements EmDgBackupStatusService {

    @Autowired
    EmDgBackupStatusRepository emDgBackupStatusRepository;

    @Override
    public ResponseEntity<?> saveStatus(EmDgBackupStatus emDgBackupStatus) {
         emDgBackupStatusRepository.save(emDgBackupStatus);
        return new ResponseEntity<>("Backup Status Details Saved Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDgBackupStatus> listAllStatus() {
        return emDgBackupStatusRepository.findAll();
    }

    @Override
    public EmDgBackupStatus getById(Long emDgBackupStatusId) {
        return emDgBackupStatusRepository.findById(emDgBackupStatusId).get();
    }
}
