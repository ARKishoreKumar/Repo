package em.dataguard.serviceimpl;

import em.dataguard.model.EmDgDatabase;
import em.dataguard.payload.EmDgDatabaseDTO;
import em.dataguard.repository.EmDgDatabaseRepository;
import em.dataguard.service.EmDgDatabaseService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class EmDgDatabaseServiceImpl implements EmDgDatabaseService {
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private EmDgDatabaseRepository emDgDatabaseRepository;

    @Override
    public ResponseEntity<?> saveDatabase(EmDgDatabaseDTO emDgDatabaseDTO) {
    EmDgDatabase emDgDatabase = modelMapper.map(emDgDatabaseDTO, EmDgDatabase.class);
    EmDgDatabase savedemDgDatabase = emDgDatabaseRepository.save(emDgDatabase);
    modelMapper.map(savedemDgDatabase, EmDgDatabaseDTO.class);

    return new ResponseEntity<>("Database Configured Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDgDatabase> findAllDatabases() {
        return emDgDatabaseRepository.findAll();
    }

    @Override
    public EmDgDatabase findDatabaseById(Long emDgDatabaseId) {
        return emDgDatabaseRepository.findById(emDgDatabaseId).get();
    }


}
