package em.dataguard.serviceimpl;

import em.dataguard.model.EmDgBackup;
import em.dataguard.model.EmDgBackupStatus;
import em.dataguard.model.EmDgRestore;
import em.dataguard.model.EmDgRestoreStatus;
import em.dataguard.payload.EmDgRestoreDTO;
import em.dataguard.repository.EmDgBackupRepository;
import em.dataguard.repository.EmDgRestoreRepository;
import em.dataguard.repository.EmDgRestoreStatusRepository;
import em.dataguard.service.EmDgRestoreService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmDgRestoreServiceImpl implements EmDgRestoreService {
    @Autowired
    EmDgRestoreRepository emDgRestoreRepository;

    @Autowired
    EmDgRestoreStatusRepository emDgRestoreStatusRepository;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    EmDgBackupRepository emDgBackupRepository;

    @Override
    public ResponseEntity<?> saveRestore(Long emDgBackupId, EmDgRestoreDTO emDgRestoreDTO) {
        EmDgBackup emDgBackup = emDgBackupRepository.findById(emDgBackupId).get();

        EmDgRestore emDgRestore = modelMapper.map(emDgRestoreDTO, EmDgRestore.class);
        emDgRestore.setEmBackup(emDgBackup);
        EmDgRestore savedEmDgRestore = emDgRestoreRepository.save(emDgRestore);
        modelMapper.map(savedEmDgRestore, EmDgRestoreDTO.class);

        EmDgRestoreStatus ob = new EmDgRestoreStatus();
        ob.setEmDgRestoreId(savedEmDgRestore.getEmDgRestoreId());
        ob.setEmDgRestoreStatus("Success");
        emDgRestoreStatusRepository.save(ob);

        return new ResponseEntity<>("Restored Database and details stored Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDgRestore> getAllRestores() {
        return emDgRestoreRepository.findAll();
    }

    @Override
    public EmDgRestore getRestoreById(Long emDgRestoreId) {
        return emDgRestoreRepository.findById(emDgRestoreId).get();
    }
}
