package em.dataguard.serviceimpl;

import em.dataguard.model.EmDgBackupStatus;
import em.dataguard.model.EmDgRestoreStatus;
import em.dataguard.repository.EmDgRestoreStatusRepository;
import em.dataguard.service.EmDgBackupStatusService;
import em.dataguard.service.EmDgRestoreStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmDgRestoreStatusServiceImpl implements EmDgRestoreStatusService {

    @Autowired
    EmDgRestoreStatusRepository emDgRestoreStatusRepository;
    @Override
    public ResponseEntity<?> saveStatus(EmDgRestoreStatus emDgRestoreStatus) {
        emDgRestoreStatusRepository.save(emDgRestoreStatus);
        return new ResponseEntity<>("Restore Status Details Saved Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDgRestoreStatus> listAllStatus() {
        return emDgRestoreStatusRepository.findAll();
    }

    @Override
    public EmDgRestoreStatus getById(Long emDgRestoreStatusId) {
        return emDgRestoreStatusRepository.findById(emDgRestoreStatusId).get();
    }
}

