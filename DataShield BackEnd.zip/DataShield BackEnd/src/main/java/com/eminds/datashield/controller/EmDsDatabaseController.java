package com.eminds.datashield.controller;
import com.eminds.datashield.dto.EmDsDatabaseDto;
import com.eminds.datashield.model.EmDsDatabase;
import com.eminds.datashield.service.EmDsDatabaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/database")
public class EmDsDatabaseController {


    @Autowired
    private EmDsDatabaseService emDsDatabaseService;


    @PostMapping("/save")
    public ResponseEntity<?> createDbDetails(@RequestBody EmDsDatabaseDto emDsDatabaseDto) {
        return emDsDatabaseService.saveDatabase(emDsDatabaseDto);
    }

    @GetMapping("/get")
    public List<EmDsDatabase> findAllDatabaseDetails() {
        return emDsDatabaseService.findAllDatabases();
    }

    @GetMapping("/get/{emDsDatabaseId}")
    public EmDsDatabase findDatabaseDetailsByID(@PathVariable("emDsDatabaseId") long emDsDatabaseId)
    {
        return emDsDatabaseService.findDatabaseById(emDsDatabaseId);
    }

    @GetMapping("/get/db/{emDsDatabaseDbType}/{emDsDatabaseServerName}/{emDsDatabasePortNumber}/{emDsDatabaseUserName}/{emDsDatabasePassword}")
    public Set<String> listDB(@PathVariable String emDsDatabaseDbType, @PathVariable String emDsDatabaseServerName,
                              @PathVariable String emDsDatabasePortNumber, @PathVariable String emDsDatabaseUserName,
                              @PathVariable String emDsDatabasePassword )
    {
        Set<String> hs = new HashSet<String>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:" + emDsDatabaseDbType +"://" + emDsDatabaseServerName +":" + emDsDatabasePortNumber + "/" ,emDsDatabaseUserName,emDsDatabasePassword  );
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("Show databases");

            while(rs.next()) {
                hs.add(rs.getString(1));
            }
        }
        catch(Exception e)
        {

        }
        return hs;
    }
}




