package com.eminds.datashield.controller;
import com.eminds.datashield.dto.EmDsDecryptionDto;
import com.eminds.datashield.dto.EmDsDecryptionDto1;
import com.eminds.datashield.dto.EmDsEncryptionDto;
import com.eminds.datashield.model.EmDsDecryption;
import com.eminds.datashield.service.EmDsDecryptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.text.*;
import java.util.Locale;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/decryption")
public class EmDsDecryptionController {

    @Autowired
    private EmDsDecryptionService emDsDecryptionService;

    @PostMapping("/save/{emDsEncryptionId}")
    public ResponseEntity<?> createEmDsDecryption(@PathVariable Long emDsEncryptionId, @RequestBody EmDsDecryptionDto emDsDecryptionDto) {
        return emDsDecryptionService.save(emDsEncryptionId, emDsDecryptionDto);
    }

        @GetMapping("/get")
        public ResponseEntity<List<EmDsDecryption>> findAllEmDsDecryption() {
            return ResponseEntity.ok(emDsDecryptionService.findAllEmDsDecryption());

        }

        @GetMapping("/get/{emDsDecryptionId}")
        public EmDsDecryption findDecryptionByID(@PathVariable("emDsDecryptionId") long emDsDecryptionId)
        {
            return emDsDecryptionService.findDecryptionByID(emDsDecryptionId);
        }

    @GetMapping("/datavalues")
    public EmDsDecryptionDto1 listDataValues( )
    {
        EmDsDecryptionDto1 ob = new EmDsDecryptionDto1();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/datashieldDB","root","root");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select em_ds_decryption_time_stamp, em_ds_decryption_name, em_ds_decryption_description from em_ds_decryption order by em_ds_decryption_time_stamp desc");
            DateFormat fmt = DateFormat.getDateTimeInstance (DateFormat.MEDIUM,
                    DateFormat.MEDIUM, Locale.UK);
            if(rs.next()) {
                ob.setEmDsDecryptionTimeStamp(fmt.format(rs.getTimestamp(1)));
                ob.setEmDsDecryptionName(rs.getString(2));
                ob.setEmDsDecryptionDescription(rs.getString(3));
            }
        }
        catch(Exception e)
        {

        }
        return ob;
    }
}
