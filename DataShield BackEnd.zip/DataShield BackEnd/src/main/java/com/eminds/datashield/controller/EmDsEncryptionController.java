package com.eminds.datashield.controller;
import com.eminds.datashield.dto.EmDsEncryptionDto;
import com.eminds.datashield.dto.EmDsEncryptionDto1;
import com.eminds.datashield.model.EmDsEncryption;
import com.eminds.datashield.service.EmDsEncryptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.text.*;
import java.util.Locale;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/encryption")
public class EmDsEncryptionController {
    @Autowired
    private EmDsEncryptionService emDsEncryptionService;

    @PostMapping("/save/{emDsDatabaseId}")
    public ResponseEntity<?> saveEncryption(@PathVariable(name="emDsDatabaseId") Long emDsDatabaseId ,@RequestBody EmDsEncryptionDto emDsEncryptionDto) {
        emDsEncryptionService.save(emDsDatabaseId,emDsEncryptionDto);
        return new ResponseEntity<>("Encrypted data stored successfully", HttpStatus.CREATED);
    }

    @GetMapping("/get")
    public List<EmDsEncryption> getAllEmDsEncryption() {
        return emDsEncryptionService.findAllEmDsEncryption();
    }

    @GetMapping("/get/{emDsEncryptionId}")
    public EmDsEncryption getEncryptionDetailsByID(@PathVariable("emDsEncryptionId") long emDsEncryptionId)
    {
        return emDsEncryptionService.findEncryptionByID(emDsEncryptionId);
    }

    @GetMapping("/datavalues")
    public EmDsEncryptionDto1 listDataValues( )
    {
        EmDsEncryptionDto1 ob = new EmDsEncryptionDto1();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/datashieldDB","root","root");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select em_ds_encryption_time_stamp, em_ds_encryption_name, em_ds_encryption_description from em_ds_encryption order by em_ds_encryption_time_stamp desc");
            DateFormat fmt = DateFormat.getDateTimeInstance (DateFormat.MEDIUM,
                    DateFormat.MEDIUM, Locale.UK);
            if(rs.next()) {
                ob.setEmDsEncryptionTimeStamp(fmt.format(rs.getTimestamp(1)));
                ob.setEmDsEncryptionName(rs.getString(2));
                ob.setEmDsEncryptionDescription(rs.getString(3));
            }
        }
        catch(Exception e)
        {

        }
        return ob;
    }


}



