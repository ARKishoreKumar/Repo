package com.eminds.datashield.data;

import com.eminds.datashield.dto.EmDsDatabaseDetailsDTO;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/datashield")
public class EncryptionController {

    @PostMapping("/encrypt")
    public void encryptDatabase(@RequestBody EmDsDatabaseDetailsDTO emDsDatabaseDetailsDTO)
    {
        try {
            //new MySQLEncryptDecryptTestService().skpDatabaseExport();
            MysqlExportService.IS_ENCRYPT=true;
            new MySQLEncryptDecryptTestService().skpDatabaseExport(emDsDatabaseDetailsDTO.getDbUserName(), emDsDatabaseDetailsDTO.getDbPassword(),
                    emDsDatabaseDetailsDTO.getTestDb(), emDsDatabaseDetailsDTO.getFileName());

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @PostMapping("/decrypt")
    public void decryptDatabase(@RequestBody EmDsDatabaseDetailsDTO emDsDatabaseDetailsDTO)
    {
        try {
            //Decrypt - Export with Decrypt, Import
            MysqlExportService.IS_ENCRYPT=false;
            new MySQLEncryptDecryptTestService().skpDatabaseImport(emDsDatabaseDetailsDTO.getDbUserName(), emDsDatabaseDetailsDTO.getDbPassword(),
                    emDsDatabaseDetailsDTO.getTestDb(), "external//sql//"+emDsDatabaseDetailsDTO.getFileName()+".sql");
            new MySQLEncryptDecryptTestService().skpDatabaseExport(emDsDatabaseDetailsDTO.getDbUserName(), emDsDatabaseDetailsDTO.getDbPassword(),
                    emDsDatabaseDetailsDTO.getTestDb(), emDsDatabaseDetailsDTO.getFileName());
            new MySQLEncryptDecryptTestService().skpDatabaseImport(emDsDatabaseDetailsDTO.getDbUserName(), emDsDatabaseDetailsDTO.getDbPassword(),
                    emDsDatabaseDetailsDTO.getTestDb(), "external//sql//"+emDsDatabaseDetailsDTO.getFileName()+".sql");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
