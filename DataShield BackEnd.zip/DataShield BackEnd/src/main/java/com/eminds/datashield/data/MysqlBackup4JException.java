package com.eminds.datashield.data;

public class MysqlBackup4JException extends RuntimeException {

    public MysqlBackup4JException(String message) {
        super(message);
    }

}
