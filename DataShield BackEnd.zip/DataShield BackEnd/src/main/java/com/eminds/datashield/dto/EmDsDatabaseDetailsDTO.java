package com.eminds.datashield.dto;

import lombok.Data;

@Data

public class EmDsDatabaseDetailsDTO {
    String dbUserName;
    String dbPassword;
    String testDb;
    String fileName;
}
