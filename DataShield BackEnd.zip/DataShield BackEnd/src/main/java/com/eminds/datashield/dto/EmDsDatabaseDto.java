package com.eminds.datashield.dto;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class EmDsDatabaseDto {
    private Long emDsDatabaseId;
    private String emDsDatabaseName;
    private String emDsFriendlyDatabaseName;
    private String emDsFriendlyDatabaseDescription;
    private String emDsDatabaseServerName;
    private long emDsDatabasePortNumber;
    private String emDsDatabaseUserName;
    private String emDsDatabasePassword;
    private String emDsDatabaseType;
    private String emDsDatabaseDiskPath;
}
