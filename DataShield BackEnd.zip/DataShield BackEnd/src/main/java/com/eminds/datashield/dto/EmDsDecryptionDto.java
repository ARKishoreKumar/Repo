package com.eminds.datashield.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Data
@Getter
@Setter
public class EmDsDecryptionDto {
    private Long emDsDecryptionId;
    private String emDsDecryptionName;
    private String emDsDecryptionDescription;

    private String emDsDecryptionAlgorithm;
    private Date emDsDecryptionTimeStamp;
    private String emDsDecryptionKey;
}
