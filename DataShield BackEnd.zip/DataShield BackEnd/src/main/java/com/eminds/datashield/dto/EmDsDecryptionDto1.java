package com.eminds.datashield.dto;

import lombok.Data;

import java.util.Date;

@Data

public class EmDsDecryptionDto1 {

    private String emDsDecryptionName;
    private String emDsDecryptionDescription;

    private String emDsDecryptionTimeStamp;

}
