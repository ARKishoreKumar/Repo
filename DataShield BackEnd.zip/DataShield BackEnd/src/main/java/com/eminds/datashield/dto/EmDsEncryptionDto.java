package com.eminds.datashield.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Data
@Getter
@Setter
public class EmDsEncryptionDto {
    private Long emDsEncryptionId;
    private String emDsEncryptionName;
    private String emDsEncryptionDescription;
    private Date emDsEncryptionTimeStamp;
    private String emDsEncryptionAlgorithm;
    private String emDsEncryptionKey;
    private String emDsEncryptionS3Id;
    private String emDsEncryptionS3Path;

}
