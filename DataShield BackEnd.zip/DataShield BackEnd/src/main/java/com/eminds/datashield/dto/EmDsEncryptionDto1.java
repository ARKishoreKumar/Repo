package com.eminds.datashield.dto;

import lombok.Data;

import java.util.Date;

@Data
public class EmDsEncryptionDto1 {

    private String emDsEncryptionName;
    private String emDsEncryptionDescription;
    private String emDsEncryptionTimeStamp;
}
