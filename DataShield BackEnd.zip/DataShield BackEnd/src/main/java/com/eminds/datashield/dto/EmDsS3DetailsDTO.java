package com.eminds.datashield.dto;

import lombok.Data;

@Data
public class EmDsS3DetailsDTO {
    String bucketName;
    String key;
}
