package com.eminds.datashield.model;

import  javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name ="EM_DS_DATABASE")
public class EmDsDatabase {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "database_Id_generator")
    @SequenceGenerator(name = "database_Id_generator",sequenceName = "database_seq", initialValue = 10001,allocationSize = 1)
    private Long emDsDatabaseId;

    private String emDsDatabaseName;

    private String emDsFriendlyDatabaseName;
    private String emDsFriendlyDatabaseDescription;
    private String emDsDatabaseServerName;
    private long emDsDatabasePortNumber;
    private String emDsDatabaseUserName;
    private String emDsDatabasePassword;
    private String emDsDatabaseType;
    private String emDsDatabaseDiskPath;
    @OneToMany(mappedBy = "emDsDatabase")
    @JsonIgnore
    private Set<EmDsEncryption> emDsEncryption;


}