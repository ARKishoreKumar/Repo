package com.eminds.datashield.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name ="EM_DS_DECRYPTION")
public class EmDsDecryption{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "decryption_gen")
    @SequenceGenerator(name = "decryption_gen",sequenceName = "decryption_seq", initialValue = 201,allocationSize = 1)
    private Long emDsDecryptionId;
    private String emDsDecryptionName;
    private String emDsDecryptionDescription;
    private String emDsDecryptionAlgorithm;
    private Date emDsDecryptionTimeStamp;
    private String emDsDecryptionKey;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="em_ds_encryption_id",nullable = false)
    private  EmDsEncryption emDsEncryption;
}

