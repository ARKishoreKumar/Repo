package com.eminds.datashield.model;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.internal.build.AllowPrintStacktrace;

import javax.persistence.*;

@NoArgsConstructor
@AllowPrintStacktrace
@Data
@Entity
@Table(name ="EM_DS_Decryption_Status")
public class EmDsDecryptionStatus{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "decryption_status_gen")
    @SequenceGenerator(name = "decryption_status_gen",sequenceName = "decryption_status_seq", initialValue = 1,allocationSize = 1)
    @Column(name="em_ds_decryption_status_id")
    private Long emDsDecryptionStatusId;
    @Column(name="em_ds_Decryption_status")
    private String emDsDecryptionStatus;
    @Column(name="em_ds_decryption_id")
    private long emDsDecryptionId;
}


