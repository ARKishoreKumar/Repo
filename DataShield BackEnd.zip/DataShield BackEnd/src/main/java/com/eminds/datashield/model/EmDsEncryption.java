package com.eminds.datashield.model;

import  javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.internal.build.AllowPrintStacktrace;

import java.util.Date;
import java.util.Set;

@NoArgsConstructor
@AllowPrintStacktrace
@Data
@Entity
@Table(name ="EM_DS_Encryption")
public class EmDsEncryption {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "encryption_gen")
    @SequenceGenerator(name = "encryption_gen",sequenceName = "encryption_seq", initialValue = 101,allocationSize = 1)
    private Long emDsEncryptionId;
    private String emDsEncryptionName;
    private String emDsEncryptionDescription;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="em_ds_database_id",nullable = false)
    private  EmDsDatabase emDsDatabase;
    private Date emDsEncryptionTimeStamp;
    private String emDsEncryptionAlgorithm;
    private String emDsEncryptionKey;
    private String emDsEncryptionS3Id;
    private String emDsEncryptionS3Path;

    @OneToMany(mappedBy = "emDsEncryption")
    @JsonIgnore
    private Set<EmDsDecryption> emDsDecryption;
}
