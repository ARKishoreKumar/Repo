package com.eminds.datashield.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.internal.build.AllowPrintStacktrace;

import javax.persistence.*;

@NoArgsConstructor
@AllowPrintStacktrace
@Data
@Entity
@Table(name ="EM_DS_Encryption_Status")
public class EmDsEncryptionStatus{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "encryption_status_gen")
    @SequenceGenerator(name = "encryption_status_gen",sequenceName = "encryption_status_seq", initialValue = 1,allocationSize = 1)
    @Column(name="em_ds_encryption_status_id")
    private Long emDsEncryptionStatusId;
    @Column(name="em_ds_encryption_status")
    private String emDsEncryptionStatus;

    @Column(name="em_ds_encryption_id")
    private long emDsEncryptionId;
}
