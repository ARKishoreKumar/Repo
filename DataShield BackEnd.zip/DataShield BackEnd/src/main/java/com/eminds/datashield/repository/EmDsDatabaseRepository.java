package com.eminds.datashield.repository;

import com.eminds.datashield.model.EmDsDatabase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface EmDsDatabaseRepository extends JpaRepository<EmDsDatabase, Long> {

}
