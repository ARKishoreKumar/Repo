package com.eminds.datashield.repository;

import com.eminds.datashield.model.EmDsDecryptionStatus;
import org.hibernate.boot.JaccPermissionDefinition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmDsDecryptionStatusRepository extends JpaRepository<EmDsDecryptionStatus, Long> {
}
