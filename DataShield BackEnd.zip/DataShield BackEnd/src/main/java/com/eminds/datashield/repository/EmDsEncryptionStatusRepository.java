package com.eminds.datashield.repository;


import com.eminds.datashield.model.EmDsEncryptionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmDsEncryptionStatusRepository extends JpaRepository<EmDsEncryptionStatus,Long> {
}
