package com.eminds.datashield.service;

import com.eminds.datashield.dto.EmDsDatabaseDto;
import com.eminds.datashield.model.EmDsDatabase;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface EmDsDatabaseService {
    public ResponseEntity<?>saveDatabase(EmDsDatabaseDto emDgDatabase);
    public List<EmDsDatabase> findAllDatabases();
    public EmDsDatabase findDatabaseById(Long emDgDatabaseId);


}
