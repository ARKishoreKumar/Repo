package com.eminds.datashield.service;

import com.eminds.datashield.dto.EmDsDecryptionDto;
import com.eminds.datashield.model.EmDsDecryption;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface EmDsDecryptionService {
    ResponseEntity<?> save(Long emDsEncryptionId, EmDsDecryptionDto emDsDecryption);
    List <EmDsDecryption> findAllEmDsDecryption();
    EmDsDecryption findDecryptionByID(Long id);

}
