package com.eminds.datashield.service;


;
import com.eminds.datashield.dto.EmDsEncryptionDto;
import com.eminds.datashield.model.EmDsEncryption;
import org.springframework.http.ResponseEntity;


import java.util.List;

public interface EmDsEncryptionService {

        ResponseEntity<?> save(Long emDsDatabaseId, EmDsEncryptionDto emDsEncryptionDto);

        List<EmDsEncryption> findAllEmDsEncryption();
        EmDsEncryption findEncryptionByID(Long id);



}
