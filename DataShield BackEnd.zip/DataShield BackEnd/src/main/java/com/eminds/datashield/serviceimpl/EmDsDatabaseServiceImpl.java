package com.eminds.datashield.serviceimpl;

import com.eminds.datashield.dto.EmDsDatabaseDto;
import com.eminds.datashield.model.EmDsDatabase;
import com.eminds.datashield.repository.EmDsDatabaseRepository;
import com.eminds.datashield.service.EmDsDatabaseService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmDsDatabaseServiceImpl implements EmDsDatabaseService {
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private EmDsDatabaseRepository emDsDatabaseRepository;

    @Override
    public ResponseEntity<?> saveDatabase (EmDsDatabaseDto emDsDatabaseDtO) {
        EmDsDatabase emDsDatabase = modelMapper.map(emDsDatabaseDtO, EmDsDatabase.class);
        EmDsDatabase savedemDsDatabase = emDsDatabaseRepository.save(emDsDatabase);
        modelMapper.map(savedemDsDatabase, EmDsDatabaseDto.class);

        return new ResponseEntity<>("Database Configured Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDsDatabase> findAllDatabases() {
        return emDsDatabaseRepository.findAll();
    }

    @Override
    public EmDsDatabase findDatabaseById(Long emDsDatabaseId) {
        return emDsDatabaseRepository.findById(emDsDatabaseId).get();
    }




}
