package com.eminds.datashield.serviceimpl;

import com.eminds.datashield.dto.EmDsDecryptionDto;
import com.eminds.datashield.model.EmDsDatabase;
import com.eminds.datashield.model.EmDsDecryption;
import com.eminds.datashield.model.EmDsDecryptionStatus;
import com.eminds.datashield.model.EmDsEncryption;
import com.eminds.datashield.repository.EmDsDatabaseRepository;
import com.eminds.datashield.repository.EmDsDecryptionRepository;
import com.eminds.datashield.repository.EmDsDecryptionStatusRepository;
import com.eminds.datashield.repository.EmDsEncryptionRepository;
import com.eminds.datashield.service.EmDsDecryptionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmDsDecryptionServiceImpl implements EmDsDecryptionService {
@Autowired
    private ModelMapper modelMapper;
@Autowired
    private EmDsDecryptionRepository emDsDecryptionRepository;
@Autowired
 private EmDsEncryptionRepository emDsEncryptionRepository;
    @Autowired
    private EmDsDatabaseRepository emDsDatabaseRepository;

    @Autowired
    private EmDsDecryptionStatusRepository emDsDecryptionStatusRepository;

    @Override
    public ResponseEntity<?> save(Long emDsEncryptionId, EmDsDecryptionDto emDsDecryptionDto) {

        EmDsEncryption emDsEncryption = emDsEncryptionRepository.findById(emDsEncryptionId).get();
        EmDsDecryption emDsDecryption = modelMapper.map(emDsDecryptionDto, EmDsDecryption.class);
        emDsDecryption.setEmDsEncryption(emDsEncryption);
        EmDsDecryption savedEmDsDecryption = emDsDecryptionRepository.save(emDsDecryption);
        modelMapper.map(savedEmDsDecryption, EmDsDecryptionDto.class);

        EmDsDecryptionStatus ob = new EmDsDecryptionStatus();
        ob.setEmDsDecryptionId(savedEmDsDecryption.getEmDsDecryptionId());
        ob.setEmDsDecryptionStatus("Success");
        emDsDecryptionStatusRepository.save(ob);

        return new ResponseEntity<>("Decryption Details Saved Successfully", HttpStatus.CREATED);
    }

    @Override
    public List<EmDsDecryption> findAllEmDsDecryption() {
        return emDsDecryptionRepository.findAll();
    }

    @Override
    public EmDsDecryption findDecryptionByID(Long emDsDecryptionId) {
        return emDsDecryptionRepository.findById(emDsDecryptionId).get();
    }

}
