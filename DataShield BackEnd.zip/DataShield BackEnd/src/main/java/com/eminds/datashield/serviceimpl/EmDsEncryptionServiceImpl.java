package com.eminds.datashield.serviceimpl;
import com.eminds.datashield.dto.EmDsEncryptionDto;
import com.eminds.datashield.model.EmDsDatabase;
import com.eminds.datashield.model.EmDsEncryption;
import com.eminds.datashield.model.EmDsEncryptionStatus;
import com.eminds.datashield.repository.EmDsDatabaseRepository;
import com.eminds.datashield.repository.EmDsEncryptionRepository;
import com.eminds.datashield.repository.EmDsEncryptionStatusRepository;
import com.eminds.datashield.service.EmDsEncryptionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class EmDsEncryptionServiceImpl implements EmDsEncryptionService {
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private EmDsEncryptionRepository emDsEncryptionRepository;
    @Autowired
    private EmDsDatabaseRepository emDsDatabaseRepository;

    @Autowired
    private EmDsEncryptionStatusRepository emDsEncryptionStatusRepository;



    @Override
    public ResponseEntity<?> save(Long emDsDatabaseId, EmDsEncryptionDto emDsEncryptionDto) {
        EmDsDatabase emDsDatabase = emDsDatabaseRepository.findById(emDsDatabaseId).get();

        EmDsEncryption emDsEncryption = modelMapper.map(emDsEncryptionDto, EmDsEncryption.class);
        emDsEncryption.setEmDsDatabase(emDsDatabase);
        EmDsEncryption savedEmDsEncryption = emDsEncryptionRepository.save(emDsEncryption);
        modelMapper.map(savedEmDsEncryption, EmDsEncryptionDto.class);

        EmDsEncryptionStatus ob = new EmDsEncryptionStatus();
        ob.setEmDsEncryptionId(savedEmDsEncryption.getEmDsEncryptionId());
        ob.setEmDsEncryptionStatus("Success");
        emDsEncryptionStatusRepository.save(ob);

        return new ResponseEntity<>("Encryption Details Saved Successfully", HttpStatus.CREATED);
    }


    @Override
    public List<EmDsEncryption> findAllEmDsEncryption() {
        return emDsEncryptionRepository.findAll();
    }

    @Override
    public EmDsEncryption findEncryptionByID(Long emDsEncryptionId) {
        return emDsEncryptionRepository.findById(emDsEncryptionId).get();
    }



}



