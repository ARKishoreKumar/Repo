package com.eminds.datashield;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataShieldApplicationTests {

	@Test
	void contextLoads() {
	}

}
